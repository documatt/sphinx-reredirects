"""
Theme for Documatt.com websites.
"""

__version__ = "1.1.1"


from pathlib import Path

from sphinx.application import Sphinx
from sphinx.util.typing import ExtensionMetadata

THEME_NAME = "sphinx_documattcom_theme"


def setup(app: Sphinx) -> ExtensionMetadata:
    """Setup the Sphinx application."""
    theme_path = str(Path(__file__).parent.resolve())
    app.add_html_theme(THEME_NAME, theme_path)

    for js in [
        "scripts/vendors/focus.min.js",
        "scripts/vendors/alpinejs.min.js",
        "scripts/vendors/aos.js",
        "scripts/main.js",
    ]:
        app.add_js_file(js, loading_method="defer")

    return {
        "parallel_read_safe": True,
        "parallel_write_safe": True,
        "version": __version__,
    }
